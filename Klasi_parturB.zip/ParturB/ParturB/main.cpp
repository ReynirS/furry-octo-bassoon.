
#include <iostream>
#include <fstream>

using namespace std;


class SuperHero
{
private:
    string name;
    int age;
    char super_power;
    
public:
    SuperHero()
    {
        name = "";
        age = 0;
        super_power = 'n';
    }
    SuperHero(string name, int age, char super_power)
    {
        this->name = name;
        this->age = age;
        this-> super_power = super_power;
    }
    
    string get_name()
    {
        return name;
    }
    
    int get_age()
    {
        return age;
    }
    
    char get_superpower()
    {
        
        return super_power;
    }
    
    friend ostream &operator << (ostream &out, SuperHero hero);
    friend istream &operator >> (istream &in, SuperHero &hero);

};

ostream &operator << (ostream &out, SuperHero hero)
{
    out << hero.name << " (" << hero.age << ") : ";
    if(hero.super_power == 'f')
    {
        out << "Flying" << endl;
    }
    else if(hero.super_power == 'g')
    {
        out << "Giant" << endl;
    }
    else if(hero.super_power == 'h')
    {
        out << "Hacker" << endl;
    }
    else if(hero.super_power == 'n')
    {
        out << "None" << endl;
    }
    else
    {
        out << "Weakling" << endl;
    }
    return out;
}

istream &operator >> (istream &in, SuperHero &hero)
{
    cout << "Name: ";
    in >> hero.name;
    cout << "Age: ";
    in >> hero.age;
    cout << "SuperPower: ";
    in >> hero.super_power;
    return in;
}

void get_info(SuperHero hero2)
{
    cout << hero2.get_name() << " (" << hero2.get_age() << ") : ";
    if(hero2.get_superpower() == 'f')
    {
        cout << "Flying" << endl;
    }
    else if(hero2.get_superpower()== 'g')
    {
        cout << "Giant" << endl;
    }
    else if(hero2.get_superpower() == 'h')
    {
        cout << "Hacker" << endl;
    }
    else if(hero2.get_superpower() == 'n')
    {
        cout << "None" << endl;
    }
    else
    {
        cout << "Weakling" << endl;
    }
}

int main()
{
   
    ifstream fin;
    ofstream fout;

    fout.open("klasi.txt",ios::app);
    
    SuperHero hero("Bjorgvin", 27, 'h');
    fout << hero;
    cout << hero;
    cout << endl;
    
    SuperHero hero2;
    cin >> hero2;
    cout << endl;
    get_info(hero2);
    
    fout << hero2;
    
}
